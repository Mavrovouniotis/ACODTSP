#define INFTY    INT_MAX
#define CHAR_LEN 100
#define TERMINATION	(total_changes*change_speed)

struct object {
  int id;
  double x;
  double y;
};

//USER INPUT PARAMETERS
extern char* problem_instance;          //Name of the instance
extern double change_degree;            //Ratio of swapped objects
extern int change_speed;                //Peiord of changes in algorithmic iterations
extern int total_changes; 		        //Number of environmental changes

//These parameter are used in the stat class
extern double offline_performance;
extern double before_change;
extern double pop_diversity;
extern double tot_robustness;

//METHODS AND PARAMETERS THAT CAN BE USED IN YOUR ALGORITHM IMPLEMENTATION
extern int **distances;                 //Distance matrix
extern int problem_size;                //Size of the instance

//Use it to evaluate the fitness of the algorithm
double fitness_evaluation(int *t);

//Use them to generate DTSP. An example is given in main.cpp
void read_problem(char* filename);
void initialize_environment();
void change_environment();

//Use them to output offline performance, diversity and best before a change
int get_current_best();
double get_offline_performance();
double get_pop_diversity();
double get_before_change();
double get_robustness();

double** generate_2D_matrix_double(int n, int m);
int** generate_2D_matrix_int(int n, int m);
void free_DTSP_memory();


