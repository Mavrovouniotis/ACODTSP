#include<iostream>
#include<stdlib.h>
#include<limits.h>
#include<math.h>

#include "DTSPwc.hpp"
#include "ACO.hpp"
#include "stats.hpp"

using namespace std;

/****************************************************************/
/*                Main Function                                 */
/****************************************************************/
int main(int argc, char *argv[]) {
  //read in parameters for example:
  //./main kroA100.tsp 0.25 100 50 1 to run RIACO for 50 environmental changes that change every 100 iterations with 0.25
  //./main kroA100.tsp 0.25 100 50 2 to run EIACO on the same DTSP
  //./main kroA100.tsp 0.25 100 50 3 to run HIACO on the same DTSP
  //./main kroA100.tsp 0.25 100 50 4 to run MIACO on the same DTSP
  //etc...
  //in particular:
  //argv[1] = kroA100.tsp
  //argv[2] = 0.25
  //argv[3] = 100
  //argv[4] = 50
  //argv[5] = 1
  problem_instance = argv[1];
  change_degree = atof(argv[2]);
  change_speed = atoi(argv[3]);
  total_changes = atoi(argv[4]);
  alg_mode = atoi(argv[5]);
  read_problem(problem_instance);   //Read TSP from file
  max_iterations = TERMINATION;     //defined by the total_changes and change_speed
  max_trials = 30;                  // Number of tries/executions.
  open_stats();                     //open text files to store statistics stats.hpp


  set_algorithm_parameters_structures();  //from ACO.hpp

  for(int run = 1; run <= max_trials; run++){
    //set the DBGP environment
    initialize_environment();  //from DBGP.hpp

    //ACO algorithms initialization and reset structures
    initialize_ACO(run);             //from ACO.hpp

    //execute algorithm for total_changes environments
    //The TERMINATATION is basically defined as (change_speed * total_changes)
    while(current_iteration < TERMINATION){
      //ACO algorithm iterative methods
      ACO(); //from ACO.hpp

      //get an observation every iteration
      get_observation(current_iteration-1); //from stat.hpp

      //synhronize dynamic changes with algorithmic iterations
      //it could be modified to change with evaluations
      if(current_iteration%change_speed==0) change_environment(); //from DTSPwc.hpp
    }
    //calculate totals for each run
    get_mean(run-1,get_offline_performance(),get_before_change(),get_pop_diversity(),get_robustness()); //from stats.hpp
   }
   close_stats(); //close text files with stored statistics from stats.h

   return 0;

   free_DTSP_memory();
   free_ACO_memory();
}
