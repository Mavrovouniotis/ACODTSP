void two_opt_first(int *tour);


