#define IA       16807
#define IM       2147483647
#define AM       (1.0/IM)
#define IQ       127773
#define IR       2836
#define MASK     123459876
#define EPSILON  0.000000000000000000000001

//Ant or individual structure that represent the TSP tour and tour cost
struct ant{
  int *tour;
  bool *visited;
  double tour_length;
  double caste;
  int id;
};

extern int** nn_list;
extern int depth;
extern double** pheromone;
extern double** heuristic;
extern double alpha;
extern double beta;
extern ant *best_so_far_ant;
extern int n_ants;
extern ant* ant_population;
extern int seed;
extern int alg_mode;
extern int current_iteration;

double distance_between(ant *a1, ant *a2);
double alg_random_number(int *idum);
void set_algorithm_parameters_structures(void);
void initialize_ACO(int r);
void ACO(void);
void free_ACO_memory();
void repair_action(void);




