/****************************************************************************/
/*                                                                          */
/*        This is an implementation of the DTSP with node changes           */
/*                                                                          */
/*                                                                          */
/****************************************************************************/

#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<string>
#include<cstring>
#include<math.h>
#include<fstream>
#include<time.h>
#include<limits.h>
#include<float.h>

#include "DTSPnc.hpp"
#include "stats.hpp"

using namespace std;


struct object *init_objects;     //Actual objects of the instance

struct object *current_pool;     //working problem instance
struct object *spare_pool;       //spare problem instance to introduce new cities
struct object *removed;
struct object *added;

int* random_vector1;    //used to store the location of cities to delete from current pool
int* random_vector2;    //used to store the location of cities to delete from spare pool

double* prob_dist1;     //generate a distribution for cities close to the selected one from current pool
double* prob_dist2;     //generate a distribution for cities close to the selected one from spare pool

int *affected;
int *offended_nodes;

int **complete_distances;        //distance matrix of the complete problem instance
int actual_problem_size;
char* problem_instance;          //Name of the instance
int **distances;                 //Distance matrix of the current pool
int problem_size;                //Number of cities


double change_degree;            //Ratio of swapped objects
int change_speed;                //Period of changes in algorithmic iterations
int total_changes; 		         //How many environmental changes

double delta = 0.0;		          //select cities in a clustered way. 0.0 = randomly

double offline_performance;
double before_change;
double pop_diversity;
double tot_robustness;

double current_best;


/****************************************************************/
/*Random number generator where the seed is the same in all runs*/
/****************************************************************/
double env_random_number(double low, double high) {
  return ((double)(rand()%10000)/10000.0)*(high - low) + low;
}

/****************************************************************/
/*Random seed used from the env_random_number() method          */
/****************************************************************/
void reset_random_seed(){
 srand(1);//static seed reset for the changes
}

/****************************************************************/
/*Generate a vector of random objects used for the swaps        */
/****************************************************************/
int *generate_random_vector(int size){
  int i, help, node, tot_assigned = 0;
  double rnd;
  int  *r;
  r = new int[size];
  //input object indexes
  for ( i = 0 ; i < size; i++){
    r[i] = i;
  }
  for ( i = 0 ; i < size ; i++ ) {
    //find an index for a object randomly
    rnd  = env_random_number(0.0,1.0);
    node = (int) (rnd  * (size - tot_assigned));//random number
    help = r[i];
    r[i] = r[i+node];
    r[i+node] = help;
    tot_assigned++;
  }
  return r;
}

/****************************************************************/
/*Compute and return the euclidean distance of two objects      */
/****************************************************************/
int euclidean_distance(int i, int j) {
  double xd,yd;
  int r = 0;
  xd = current_pool[i].x - current_pool[j].x;
  yd = current_pool[i].y - current_pool[j].y;
  r  = sqrt(xd*xd + yd*yd) + 0.5;
  return r;
}

/****************************************************************/
/*Compute the distance matrix of the problem instance           */
/****************************************************************/
void compute_distances(void) {
  for(int i = 0; i < problem_size; i++){
    for(int j = 0; j < problem_size; j++){
      distances[i][j] = euclidean_distance(i,j);
    }
  }
}

/*Compute distances for the whole problem instance*/
int euclidean_distance_actual(int i, int j) {
  double xd,yd;
  int r = 0;
  xd = init_objects[i].x - init_objects[j].x;
  yd = init_objects[i].y - init_objects[j].y;
  r  = sqrt(xd*xd + yd*yd) + 0.5;
  return r;
}

void compute_distances_actual(void) {
  for(int i = 0; i < actual_problem_size; i++){
    for(int j = 0; j < actual_problem_size; j++){
      complete_distances[i][j] = euclidean_distance_actual(i,j);
    }
  }
}



/****************************************************************/
/*Replace two cities                                            */
/****************************************************************/
void replace_cities(int obj1, int obj2){
  current_pool[obj1].x = spare_pool[obj2].x;
  current_pool[obj1].y = spare_pool[obj2].y;
  current_pool[obj1].id = spare_pool[obj2].id;
}


/****************************************************************/
/* Perform random changes by swapping the first                 */
/* (change_degree * problem_size) objects randomly              */
/****************************************************************/
void add_random_change(void){
  int i,j, changes,  obj1, obj2;
  bool* selected = new bool[problem_size];

  double rnd;
  double sum_prob = 0.0;
  double partial_sum = 0.0;
  int select;

   changes = (int)abs(change_degree * problem_size);
    //select cities randomly
    random_vector1 = new int[changes];
    random_vector2 = new int[changes];
    int selected1 = env_random_number(0,problem_size);
    int selected2 = env_random_number(0,problem_size);
    random_vector1[0] = selected1;
    random_vector2[0] = selected2;
    //generate distributions for the two selected cities
    for(i = 0; i < problem_size; i++){
        if(i == selected1)
            prob_dist1[i] = 0.0;
        else
            prob_dist1[i] = pow(1.0/(complete_distances[current_pool[selected1].id][current_pool[i].id] + 0.00001), delta);
        if(i == selected2)
            prob_dist2[i] = 0.0;
        else
            prob_dist2[i] = pow(1.0/(complete_distances[spare_pool[selected2].id][spare_pool[i].id] + 0.00001), delta);
    }
    //select the first city
    for(j = 0; j < problem_size; j++)
        selected[j] = false;
    selected[random_vector1[0]] = true;
    for(i = 0; i < changes-1; i++){
        sum_prob = 0.0;
        for(j = 0; j < problem_size; j++){
            if(selected[j] == true){
               prob_dist1[j] = 0.0 ;
            } else {
                sum_prob+=prob_dist1[j];
            }
        }
        rnd = env_random_number(0.0,1.0);
        rnd *= sum_prob;
        select = 0;
        partial_sum = prob_dist1[select];
        while(partial_sum<=rnd){
            select++;
            partial_sum+=prob_dist1[select];
        }
        selected[select] = true;
        random_vector1[i+1] = select;
    }
    //select the second city
    for(j = 0; j < problem_size; j++)
        selected[j] = false;
    selected[random_vector2[0]] = true;
    for(i = 0; i < changes-1; i++){
        sum_prob = 0.0;
        for(j = 0; j < problem_size; j++){
            if(selected[j] == true){
                prob_dist2[j] = 0.0 ;
            } else {
                sum_prob+=prob_dist2[j];
            }
        }
        rnd = env_random_number(0.0,1.0);
        rnd *= sum_prob;
        select = 0;
        partial_sum = prob_dist2[select];
        while(partial_sum<=rnd){
            select++;
            partial_sum+=prob_dist2[select];
        }
        selected[select] = true;
        random_vector2[i+1] = select;
    }

    //replace cities selected from spare pool to current pool
    for (i = 0; i < changes; i++){
        obj1 = random_vector1[i];
        obj2 = random_vector2[i];
        //copy removed from current pool and added from spare pool
        removed[i].x = current_pool[obj1].x;
        removed[i].y = current_pool[obj1].y;
        removed[i].id = current_pool[obj1].id;
        affected[i+changes] = removed[i].id;
        offended_nodes[i] = obj1; // location of offended cities
        added[i].x = spare_pool[obj2].x;
        added[i].y = spare_pool[obj2].y;
        added[i].id = spare_pool[obj2].id;
        affected[i] = added[i].id;
        //replace removed with spare pool
        replace_cities(obj1, obj2);
        //copy removed from current pool to spare pool
        spare_pool[obj2].x = removed[i].x;
        spare_pool[obj2].y = removed[i].y;
        spare_pool[obj2].id = removed[i].id;
        //cout << i <<" : "<< current_pool[random_vector1[i]].id << " " << spare_pool[random_vector2[i]].id << endl;
    }

	delete[] selected;

}


/****************************************************************/
/*Generate and return a two-dimension array of type int         */
/****************************************************************/
int ** generate_2D_matrix_int(int n, int m){
  int **matrix;
  matrix = new int*[n];
  for ( int i = 0 ; i < n ; i++ ) {
    matrix[i] = new int[m];
  }
  //initialize 2-d array
  for(int i = 0; i < n; i++){
    for(int j = 0; j < m; j++) {
      matrix[i][j] = 0;
    }
  }
  return matrix;
}


/****************************************************************/
/*Generate and return a two-dimension array of type double      */
/****************************************************************/
double ** generate_2D_matrix_double(int n, int m){
  double **matrix;

  matrix = new double*[n];
  for ( int i = 0 ; i < n ; i++ ) {
    matrix[i] = new double[m];
  }
  //initialize the 2-d array
  for(int i = 0; i < n; i++){
    for(int j = 0; j < m; j++) {
      matrix[i][j] = 0.0;
    }
  }
  return matrix;
}

/****************************************************************/
/* Validate the values input by the user                        */
/****************************************************************/
void check_input_parameters() {

 if(problem_size == 0) {
   cout << "wrong problem instance file" << endl;
   exit(1);
 }
 if(change_degree > 1.0 || change_degree <= 0.0) {
   cout << "select a valid change degree (between 0..1)" << endl;
   exit(2);
 }
 if(change_speed <= 0) {
   cout << "select a valid change speed (int)" << endl;
   exit(1);
 }
 if(total_changes <= 0) {
    cout << "select total changes" << endl;
 }
}

/****************************************************************/
/* Read the problem instance and generate the initial object    */
/* vector.                                                      */
/****************************************************************/
void read_problem(char* filename){
  char line[CHAR_LEN];
  char * keywords;
  char Delimiters[] = " :=\n\t\r\f\v";
  ifstream fin(filename);
  while((fin.getline(line, CHAR_LEN-1))){
    if(!(keywords = strtok(line, Delimiters)))
      continue;
    if(!strcmp(keywords, "DIMENSION")){
      if(!sscanf(strtok(NULL, Delimiters), "%d", &actual_problem_size)){
	cout<<"DIMENSION error"<<endl;
	exit(0);
      }
    }
    else if(!strcmp(keywords, "EDGE_WEIGHT_TYPE")){
      char * tempChar;
      if(!(tempChar=strtok(NULL, Delimiters))){
	cout<<"EDGE_WEIGHT_TYPE error"<<endl;
	exit(0);
      }
      if(strcmp(tempChar, "EUC_2D")){
	cout<<"not EUC_2D"<<endl;
	exit(0);
      }
    }
    else if(!strcmp(keywords, "NODE_COORD_SECTION")){
      actual_problem_size *= 2;
      problem_size =  actual_problem_size / 2;
      if(actual_problem_size!=0){
      init_objects = new object[actual_problem_size];
      int i,k;
      for(i=0; i < problem_size; i++){
        //store initial objects
        fin>>init_objects[i].id;
	    fin>>init_objects[i].x>>init_objects[i].y;
        init_objects[i].id -=1;
      }

      double max_y = init_objects[0].y;
      double min_y = init_objects[0].y;
      double max_x = init_objects[0].x;
      double min_x = init_objects[0].x;
      //find max and min bounds
      for(i = 0; i < problem_size; i++){
         if (init_objects[i].x > max_x) max_x = init_objects[i].x;
         if (init_objects[i].x < min_x) min_x = init_objects[i].x;
         if (init_objects[i].y > max_y) max_y = init_objects[i].y;
         if (init_objects[i].y < min_y) min_y = init_objects[i].y;
      }
      //cout << max_x  << " " << min_x << " " << max_y << " " << min_y << endl;
      //generate spare pool
      for(i =0; i < problem_size; i++){
        init_objects[problem_size+i].id = problem_size+i;
        init_objects[problem_size+i].x = (int)env_random_number(min_x,max_x);
        init_objects[problem_size+i].y = (int)env_random_number(min_y,max_y);
      }

     // for(i = 0; i < actual_problem_size; i++)
       // cout << "id: " << init_objects[i].id << " x: " << init_objects[i].x << " y: " << init_objects[i].y << endl;


     current_pool = new object[problem_size];
     spare_pool = new object[problem_size];
     removed = new object[problem_size];
     added = new object[problem_size];
     offended_nodes = new int[problem_size];
     affected = new int[actual_problem_size];
     prob_dist1 = new double[problem_size];
     prob_dist2 = new double[problem_size];
     //compute the distances using initial objects
     distances = generate_2D_matrix_int(problem_size, problem_size);
     compute_distances();//for current pool
     complete_distances = generate_2D_matrix_int(actual_problem_size,actual_problem_size);
     compute_distances_actual(); //for all objects
     }
    }
  }
  fin.close();
  check_input_parameters();         //validate the parameters
}

/****************************************************************/
/* Initialize the environment with the initial objects and      */
/* perform the initial dynamic change/generate base states      */
/****************************************************************/
void initialize_environment(){
  int i, k = 0;
  //Set the random seed
  reset_random_seed();
  //reset the metrics
  offline_performance = 0.0;
  before_change = 0.0;
  pop_diversity = 0.0;
  tot_robustness = 0.0;
  //split the problem instance to current and spare pool

  for(i = 0; i < actual_problem_size; i++){
    if(i < problem_size) {
           current_pool[i].id = init_objects[i].id;
           current_pool[i].x = init_objects[i].x;
           current_pool[i].y = init_objects[i].y;
    } else{
        spare_pool[i-problem_size].id = init_objects[i].id;
        spare_pool[i-problem_size].x = init_objects[i].x;
        spare_pool[i-problem_size].y = init_objects[i].y;
    }
    //cout << current_pool[k].id << " " << spare_pool[k].id << endl;
    k++;
  }

  add_random_change();
  compute_distances();
  current_best = INFTY;
}

/****************************************************************/
/* Perform the dynamic change every "period" iteration, i.e.,   */
/* swapping objects                                             */
/****************************************************************/
void change_environment(){

    add_random_change();
    compute_distances();
    current_best = INFTY;
}

/****************************************************************/
/* Evaluate a TSP tour and return the length. This method can   */
/* be used in the optimizer integrated with DBGP. The TSP tour  */
/* to input is an array of integers, where each integer         */
/* corresponds to an object                                     */
/****************************************************************/
double fitness_evaluation(int *t) {
  int i;
  double tour_length = 0.0;

  //The last city of the input "t" must be the same with the first city
  for (i = 0 ; i < problem_size; i++ ) {
    tour_length += distances[t[i]][t[(i+1)%problem_size]];
  }
  //keep track of the best so far after a change
  if(tour_length < current_best){
    current_best = tour_length;
  }

  return tour_length;
}


/*This method detects the location of change*/
bool check_offended_city(int i){
    int k;
    int flag = false;
    int size = (int)abs(change_degree * problem_size);
    for(k = 0; k < size; k++){
        //offended_nodes denotes the location
        if(offended_nodes[k] == i){
            flag = true;
            break;
        }
    }
    return flag;
}

/*The following methods use problem specific knowledge of the problem to repair solution*/
int* add_between(int *t, int size, int pos, int node){
    int i, j;
    int* temp = new int[size];
    i = 0;
    j = 0;
    while(i < size-1){
        if(i == pos){
             temp[i] = t[i];
             i++;
             temp[i] = node;
             //i++;
             j = 1;
        } else {
            temp[i+j] = t[i];
            i++;

        }
    // cout << temp[i] << ",";
    }
   // cout << " " << endl;
 return temp;
}

//this method uses problem specific knowledge to repair a solution
void repair_solution_heuristically(int *t){
  int i,j,h;
  int count, count2;
  int size = (int)abs(change_degree * problem_size); // size of offended cities
  int p1, s1;
  double radius = 0.0;
  double min;
  int min_i;
  int* temp_sol = new int[problem_size+1];
  int* help_sol = new int[problem_size-size+1];
  int* rem_sol = new int[size];
  int* temp  = new int[problem_size+1];
  int temp_size;
  //remove offended cities
  count=count2 = 0;
  for(i = 0; i < problem_size; i++){
    if(check_offended_city(t[i]) == false){
        //store present cities in help_sol
        help_sol[count] = t[i];
        count++;
    } else {
        rem_sol[count2] = t[i];
        count2++;
    }
  }
  temp_size = problem_size-size;
  for(i = 0; i < temp_size; i++){
    temp_sol[i] = help_sol[i];
    // cout << temp_sol[i] << ",";
  }

  temp_sol[temp_size] = temp_sol[0];
  //cout << temp_sol[temp_size] << "," << endl;
  //cout << " " << size <<endl;
  for(j = 0; j < size; j++){
     min = DBL_MAX;
    //find the best place
     for(i = 0; i < temp_size; i++){
         s1 = temp_sol[i+1];
          radius = -distances[temp_sol[i]][s1] +distances[temp_sol[i]][rem_sol[j]] + distances[rem_sol[j]][s1];
            if(min > radius){
                min = radius;
                min_i = i;
            }
     }
     //added single node to temp_sol
     temp_size++;
     //cout << radius << " " << min_i << endl;
     temp = add_between(temp_sol,temp_size,min_i,rem_sol[j]);
     for(i = 0; i < temp_size; i++){
        temp_sol[i] = temp[i];
     }
     temp_sol[temp_size] = temp_sol[0];
  }
  for(i = 0; i < problem_size+1; i++){
    t[i] = temp_sol[i];
  }
  delete[] rem_sol;
  delete[] temp_sol;
  delete[] help_sol;

}


/*return performance and behaviour measurements */
double get_offline_performance(){
    return offline_performance/(double)TERMINATION;
}

double get_before_change(){
    return before_change/(double)total_changes;
}

double get_pop_diversity(){
    return pop_diversity/(double)TERMINATION;
}

double get_robustness(){
    return tot_robustness/((double)total_changes-1);
}

int get_current_best(){
    return current_best;
}

int get_problem_size(){
    return problem_size;
}

//free memory
void free_DTSP_memory(){
  delete[] random_vector1;
  delete[] random_vector2;
  delete[] offended_nodes;
  delete[] spare_pool;
  delete[] current_pool;
  delete[] init_objects;
  delete[] removed;
  delete[] added;
  for(int i =0; i < problem_size; i++) {
    delete[] distances[i];
  }
  delete[] distances;

  for(int i =0; i < actual_problem_size; i++) {
    delete[] complete_distances[i];
  }
  delete[] complete_distances;

}

