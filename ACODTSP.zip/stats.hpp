void open_stats(void);
void close_stats(void);
double mean(double* values, int size);
double stdev(double* values, int size, double average);

/*performance measurements*/
void get_observation(int t);
/*behaviour mesaurements */
double calc_diversity(int size);
double calc_lambda(double l, int size, int depth, double** pheromone);
double calc_entropy(int size, int depth, double** pheromone, double** heuristic, double a, double b);
/*calculate averages of all trials*/
void get_mean(int r, double value,double before, double div, double rob);

extern int max_trials;
extern int max_iterations;
