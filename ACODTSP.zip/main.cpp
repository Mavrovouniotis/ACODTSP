/*
This is the implementation of the Dynamic Benchmark Framework in the following paper:

Ant Colony Optimization Algorithms for Dynamic Optimization: A Case Study of the 
Dynamic Travelling Salesperson Problem

Written by Michalis Mavrovouniotis, 2019.

If any queries or to report bugs/improvements, please email Michalis Mavrovouniotis
at m.mavrovouniotis@hotmail.com 

The code was developed and tested under Linux, but it should have no issues to run 
under Windows or other Unix Operating Systems.
*/


#include<iostream>
#include<stdlib.h>
#include<limits.h>
#include<math.h>

#include "DTSP.hpp"
#include "ACO.hpp"
#include "stats.hpp"

using namespace std;

/****************************************************************/
/*                Main Function                                 */
/****************************************************************/
int main(int argc, char *argv[]) {
  /*read in parameters for example:
  ./main kroA100.tsp 1 0.25 100 50 1 to run MMAS for 50 node changes that change every 100 iterations with 0.25
  ./main kroA100.tsp 1 0.25 100 50 2 to run PACO on the same DTSP
  ./main kroA100.tsp 1 0.25 100 50 3 to run EIACO on the same DTSP
  ./main kroA100.tsp 1 0.25 100 50 4 to run MC-MMAS on the same DTSP
  etc...
  in particular:
  argv[1] = kroA100.tsp
  argv[2] = 1
  argv[3] = 0.25
  argv[4] = 100
  argv[5] = 50
  argv[6] = 1*/
  problem_instance = argv[1];
  type_of_change = atoi(argv[2]);
  change_degree = atof(argv[3]);
  change_speed = atoi(argv[4]);
  total_changes = atoi(argv[5]);
  alg_mode = atoi(argv[6]);
  read_problem(problem_instance);   /*read TSP from file*/
  max_iterations = TERMINATION;     /*defined by the total_changes and change_speed*/
  max_trials = 10;                  /*Number of tries/executions*/
  open_stats();                     /*open text files to store statistics from stats.hpp*/


  set_algorithm_parameters_structures();  /*from ACO.hpp*/

  for(int run = 1; run <= max_trials; run++){

    /*set the DBGP environment from DBGP.hpp*/
    initialize_environment(); 
    cout << "pass" << endl;
    /*ACO algorithms initialization and reset structures from ACO.hpp*/
    initialize_ACO(run);           

    /*execute algorithm for total_changes environments
    The TERMINATATION is basically defined as (change_speed * total_changes)*/
    while(current_iteration < TERMINATION){
      /*ACO algorithm iterative methods from ACO.hpp*/
      ACO(); 

      /*get an observation every iteration from stat.hpp*/
      get_observation(current_iteration-1); 

      /*synhronize dynamic changes with the algorithm from DTSP.hpp*/
      if(current_iteration%change_speed==0)  {
        change_environment(); 
        if(alg_mode==3) repair();
        
      }
    }
    /*calculate totals for each run from stats.hpp*/
    get_mean(run-1,get_offline_performance(),get_before_change(),get_pop_diversity(),get_robustness());
  }
  /*close text files with stored statistics from stats.h*/
  close_stats(); 


  free_DTSP_memory();
  free_ACO_memory();

  return 0;

 }
