/* This is the implementation of all ACO algorithms presented in the following paper:

Ant colony optimization algorithms for dynamic problems: a critical evaluation and comparison

Written by Michalis Mavrovouniotis, 2018.

The implementation is based on the original ACO framework implementation
of Thomas Stuetzle. ACOTSP, Version 1.03. Available from
http://www.aco-metaheuristic.org/aco-code, 2004.

If any queries or to report bugs/improvements, please email Michalis Mavrovouniotis
at m.mavrovouniotis@hotmail.com 

The code was developed and tested under Linux, but it should have no issues to run 
under Windows or other Unix Operating Systems.
*/

#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<string>
#include<cstring>
#include<math.h>
#include<fstream>
#include<cmath>
#include<time.h>
#include<limits.h>
#include<float.h>

#include "ACO.hpp"
#include "DTSPnc.hpp"
#include "ls.hpp"

using namespace std;


int alg_mode;  /*1: MMAS, 2: P-ACO, 3: EIACO, 4: MultiColonyMMAS (2 colonies)*/       
                

struct ant *ant_population;    //Population of ants or individuals
ant *best_so_far_ant;          //current best so far tour
ant *previous_best_so_far_ant; //current-1 best so far tour
ant *detector;                 //current best so far tour
//General ACO parameters
double alpha;
double beta;
double q_0;
double trail0;
double rho;
double **pheromone;          //Pheromone matrix
double **heuristic;           //Heuristic information matrix
double **total;              //Pheromone + Heuristic information matrix
int n_ants;                //Population size
int depth;                 //Candidate list size (nearest neighbour)
int **nn_list;             //Candidate lists
double *prob_of_selection;
//Multicolony MMAS
bool new_best_found;
ant *restart_best_ant_1;       //current best so far tour
ant *restart_best_ant_2;       //current best so far tour
ant *best_so_far_ant_1;         //current best so far tour
ant *best_so_far_ant_2;         //current best so far tour
double **pheromone1;          //Pheromone matrix
double **total1;              //Pheromone + Heuristic information matrix
double **pheromone2;          //Pheromone matrix
double **total2;              //Pheromone + Heuristic information matrix
double trail_max_1;       //maximum pheromone trail in MMAS
double trail_min_1;       //minimum pheromone trail in MMAS
double trail_max_2;       //maximum pheromone trail in MMAS
double trail_min_2;       //minimum pheromone trail in MMAS 
int restart_found_best_1;
int restart_iteration_1;
int restart_found_best_2;
int restart_iteration_2;
//MMAS
double trail_max;       //maximum pheromone trail in MMAS
double trail_min;       //minimum pheromone trail in MMAS
int u_gb = INFTY;       //every u_gb iterations update with best-so-far ant
ant *restart_best_ant;         //current best so far tour
int found_best;
int restart_found_best;
int restart_iteration;
double found_branching;
double lambda;
double branching_factor;
double branch_fac = 1.00001;
//EIACO
struct ant *short_memory; //Short memory for RIACO,EIACO,HIACO and MIACO
double immigrant_rate;    //Immigrants replacement ratio
double p_mi;              //Immigrants mutation probability(EIACO,HIACO,MIACO)
int short_memory_size;    //Short memory size
//P-ACO
struct ant *long_memory;
int long_memory_size;     //Long memory size

//General algorithmic parameters
int current_iteration ;         //Used to calculate the period of change
int seed;                      //changing seed for the algorithms
bool ls_flag = false;          //indicates whether and which local search is used


/****************************************************************/
/*                     Initialization                           */
/****************************************************************/
void allocate_ants(void){
  int i;

  ant_population = new ant[n_ants];
  for(i = 0; i < n_ants; i++){
    ant_population[i].tour = new int[problem_size+1];
    ant_population[i].visited = new bool[problem_size];
    if(alg_mode == 4){
        if(i < (ceil(n_ants/2.0))) {
            ant_population[i].id = 1;
        } else {
            ant_population[i].id = 2;
        }
    }
  }

  best_so_far_ant = new ant;
  best_so_far_ant->tour = new int[problem_size+1];
  best_so_far_ant->visited = new bool[problem_size];

  prob_of_selection = new double[depth+1];

  prob_of_selection[depth] = HUGE_VAL;

  previous_best_so_far_ant = new ant;
  previous_best_so_far_ant->tour = new int[problem_size+1];
  previous_best_so_far_ant->visited = new bool[problem_size];

  restart_best_ant = new ant;
  restart_best_ant->tour = new int[problem_size+1];
  restart_best_ant->visited = new bool[problem_size];

  if(alg_mode == 4) {
    best_so_far_ant_1 = new ant;
    best_so_far_ant_1->tour = new int[problem_size+1];
    best_so_far_ant_1->visited = new bool[problem_size];

    best_so_far_ant_2 = new ant;
    best_so_far_ant_2->tour = new int[problem_size+1];
    best_so_far_ant_2->visited = new bool[problem_size];

    restart_best_ant_1 = new ant;
    restart_best_ant_1->tour = new int[problem_size+1];
    restart_best_ant_1->visited = new bool[problem_size];

    restart_best_ant_2 = new ant;
    restart_best_ant_2->tour = new int[problem_size+1];
    restart_best_ant_2->visited = new bool[problem_size];
  }
  detector = new ant;
  detector->tour = new int[problem_size+1];
  detector->visited = new bool[problem_size];
}


void allocate_structures(void){
  int i;

  pheromone = generate_2D_matrix_double(problem_size,problem_size);
  heuristic = generate_2D_matrix_double(problem_size,problem_size);
  total = generate_2D_matrix_double(problem_size,problem_size);
  nn_list = generate_2D_matrix_int(problem_size,depth);
  if(alg_mode == 3){
    short_memory = new ant[short_memory_size];
    for(i = 0; i < short_memory_size; i++){
        short_memory[i].tour = new int[problem_size+1];
    }
   }

  if(alg_mode == 2 ){ //initialize long memory for MIACO
    long_memory = new ant[long_memory_size];
    for(i =0; i < long_memory_size; i++){
      long_memory[i].tour = new int[problem_size+1];
    }
  }
  if(alg_mode == 4){
    pheromone1 = generate_2D_matrix_double(problem_size,problem_size);
    total1 = generate_2D_matrix_double(problem_size,problem_size);
    pheromone2 = generate_2D_matrix_double(problem_size,problem_size);
    total2 = generate_2D_matrix_double(problem_size,problem_size);
  }
}


void set_algorithm_parameters_structures(void){
  //default parameters of algorithms.
  alpha = 1;
  beta = 5;
  depth = 20;
  //set population size
  n_ants = 5;
  if(alg_mode == 1 || alg_mode == 4) {

    lambda = 0.05;
    //set evaporation rate
    rho = 0.8;
    q_0 = 0.0;
  } 
  if(alg_mode == 2 || alg_mode == 3) {
    p_mi = 0.01;
    short_memory_size = 3;
    long_memory_size = 3;
    immigrant_rate = 0.5;
    q_0 = 0.9;
  }
  //generate and initialize structures
  allocate_ants();
  allocate_structures();
 }



void swap(int v[], int v2[],  int i, int j){
  int tmp;

  tmp = v[i];
  v[i] = v[j];
  v[j] = tmp;
  tmp = v2[i];
  v2[i] = v2[j];
  v2[j] = tmp;
}

void sort(int v[], int v2[], int left, int right){
  int k, last;

  if (left >= right)
    return;
  swap(v, v2, left, (left + right)/2);
  last = left;
  for (k=left+1; k <= right; k++)
    if (v[k] < v[left])
      swap(v, v2, ++last, k);
  swap(v, v2, left, last);
  sort(v, v2, left, last);
  sort(v, v2, last+1, right);
}

void compute_nn_lists( void ){
  int i,j;
  int *distance_vector;
  int *help_vector;

  distance_vector = new int[problem_size];
  help_vector = new int[problem_size];
  //compute the nearest neigbhours of the objects
  for (j  = 0 ; j < problem_size; j++ ) {
    for (i = 0 ; i < problem_size; i++ ) {
      distance_vector[i] = distances[j][i];
      help_vector[i] = i;
    }
    distance_vector[j] = INT_MAX;
    sort(distance_vector, help_vector, 0, problem_size-1);
    for (i = 0 ; i < depth ; i++ ) {
      nn_list[j][i] = help_vector[i];
    }
  }

  //free memory
  delete[] distance_vector;
  delete[] help_vector;
}

void init_pheromone_trails(double **pheromone, double **total, double initial_trail){
  int i,j;
 //cout << "INIT TRAILS!!!" << endl;
  for(i = 0; i < problem_size; i++){
    for(j = 0; j <=i; j++){
      pheromone[i][j] = initial_trail;
      pheromone[j][i] = initial_trail;
      total[i][j] = initial_trail;
      total[j][i] = initial_trail;
    }
  }
}

void init_heuristic_info(void){
  int i,j;

  for(i = 0; i <problem_size; i++){
    for(j = 0; j <=i; j++){
      heuristic[i][j] = 1.0/(double)(distances[i][j] + EPSILON); //small value to avoid 1 div 0
      heuristic[j][i] = heuristic[i][j];
    }
  }
}

void compute_total_info(double **total, double **pheromone){
  int i,j;

  for(i = 0; i < problem_size; i++){
    for(j = 0; j < i; j++){
      total[i][j] = pow(pheromone[i][j],alpha) * pow(heuristic[i][j],beta);
      total[j][i] = total[i][j];
    }
  }
}

/****************************************************************/
/*                    Construct Solutions                       */
/****************************************************************/
void ant_empty_memory(ant *a){
  int i;
  //clear previous ant solution
  for(i =0; i < problem_size; i++){
    a->visited[i] = false;
  }
}

double alg_random_number(int *idum){
  int k;
  double ans;
  //uniformly distributed random number [0,1]
  k =(*idum)/IQ;
  *idum = IA * (*idum - k * IQ) - IR * k;
  if (*idum < 0 ) *idum += IM;
  ans = AM * (*idum);
  return ans;
}

void place_ant(ant *a, int step){
  int rnd;
  //place ants to randomly selected cities
  rnd = (int)(alg_random_number(&seed) * (double)problem_size);
  a->tour[step] = rnd;
  a->visited[rnd] = true;
}

void choose_best_next(ant *a, int phase, double **total){
  int i,current, next;
  double value_best;

  next = problem_size;
  current = a->tour[phase-1]; //current object of ant
  value_best = -1.0;  //values in the list are always >=0.0
  //choose the next object with maximal (pheromone+heuristic) value
  //among all objects of the problem
  for(i = 0; i < problem_size; i++){
    if(a->visited[i])
      ;//if object not visited
    else {
      if(total[current][i] > value_best){
  next = i;
  value_best = total[current][i];
      }
    }
  }
  a->tour[phase] = next;
  a->visited[next] = true;
}

void neighbour_choose_best_next(ant *a, int phase, double **total){
  int i,current,next,temp;
  double value_best, help;

  next = problem_size;
  current = a->tour[phase-1]; //current object of ant
  value_best = -1.0; //values in the list are always >=0.0
  //choose the next object with maximal (pheromone+heuristic) value
  //among all the nearest neighbour objects
  for(i =0; i < depth; i++){
    temp = nn_list[current][i];
    if(a->visited[temp])
      ;//if object not visited
   else {
      help = total[current][temp];
      if(help > value_best){
  value_best=help;
  next = temp;
      }
    }
  }
  if(next == problem_size){
    //if all nearest neighnour objects are already visited
    choose_best_next(a,phase,total);
  }else {
    a->tour[phase] = next;
    a->visited[next] = true;
  }
}

void neighbour_choose_and_move_to_next(ant *a, int phase, double **total){
  int i,help, current, select;
  double rnd;
  double partial_sum = 0.0;
  double sum_prob = 0.0;
  double *prob_ptr;

  if((q_0 > 0.0) && (alg_random_number(&seed) < q_0)) {
        //with probability q_0 make the best possible choice
        neighbour_choose_best_next(a,phase,total);
        return;
  }
  
  prob_ptr = prob_of_selection; //selection probabilities of the nearest neigbhour objects
  current = a->tour[phase-1]; //current object
  //compute selection probabilities of nearest neigbhour objects
  for(i = 0; i < depth; i++){
    if(a->visited[nn_list[current][i]]){
      prob_ptr[i] = 0.0;
    }else{
      prob_ptr[i] = total[current][nn_list[current][i]];
      sum_prob +=prob_ptr[i];
    }
  //cout << i << " " << prob_ptr[i] <<endl;
  }
  if(sum_prob <=0.0){
    //in case all neigbhbour objects are visited
    choose_best_next(a,phase,total);
  } else{
    //proabilistic selection (roullete wheel)
    rnd = alg_random_number(&seed);
    rnd *= sum_prob;
    select = 0;
    partial_sum = prob_ptr[select];
    while(partial_sum<=rnd){
      select++;
      partial_sum+=prob_ptr[select];
    }
    //this may very rarely happen because of rounding if
    //rnd is close to 1
    if(select==depth){
      neighbour_choose_best_next(a,phase,total);
      return;
    }
    help = nn_list[current][select];
    a->tour[phase] = help;
    a->visited[help] = true;
  }
}


bool detect_change_single(){
  int i,total_before, total_after;
  bool flag = false;

  total_before=total_after=0;
  //calculate total cost before dynamic change

  total_before = detector->tour_length;

  //calculate total cost after dynamic change

    detector->tour_length = fitness_evaluation(detector->tour);
    total_after = detector->tour_length;

  //is different then a dynamic change occured
  if(total_after == total_before)
    flag = false;
  else
    flag= true;

  return flag;
}

void choose_closest_next(ant *a, int phase){
  int i,current,next,min;
  next = problem_size;
  current = a->tour[phase-1]; //current object of ant
  min = INT_MAX;
  //choose closest object used in the nn_tour()
  for(i = 0; i < problem_size; i++){
    if(a->visited[i] == false){
      //if object not visited
      if(distances[current][i] < min){
  next = i;
  min = distances[current][i];
      }
    }
  }
  a->tour[phase] = next;
  a->visited[next] = true;
}

void copy_from_to(ant *a1, ant *a2){
  int i;
  //ant2 is a copy of ant1
  a2->tour_length = a1->tour_length;
  for(i = 0; i < problem_size; i++){
    a2->tour[i]=a1->tour[i];
  }
  a2->tour[problem_size] = a2->tour[0];
}

int nn_tour(void){
  int phase, help;
  phase=help=0;
  ant_empty_memory(&ant_population[0]);
  place_ant(&ant_population[0],phase);
  //compute the tour length of the nearest neigbour heuristic
  //used to initialize the pheromone trails
  while(phase < problem_size -1){
    phase++;
    choose_closest_next(&ant_population[0],phase);
  }
  phase = problem_size;
  ant_population[0].tour[problem_size] = ant_population[0].tour[0];
  ant_population[0].tour_length = fitness_evaluation(ant_population[0].tour);

  if(current_iteration == 0) copy_from_to(&ant_population[0], previous_best_so_far_ant); // copy for first iteration of EIACO

  help = ant_population[0].tour_length;
  ant_empty_memory(&ant_population[0]);

  return help;
}

/*MMAS*/
double node_branching(double l) {
  int  i, m;
  double min, max, cutoff;
  double avg;
  double *num_branches = new double[problem_size];
  /*for (i = 0; i < problem_size; i++){
    num_branches[i] = 0.0;
  }*/
  for ( m = 0 ; m < problem_size ; m++ ) {
    /* determine max, min to calculate the cutoff value */
    min = pheromone[m][nn_list[m][1]];
    max = pheromone[m][nn_list[m][1]];
    for ( i = 1 ; i < depth ; i++ ) {
      if ( pheromone[m][nn_list[m][i]] > max )
        max = pheromone[m][nn_list[m][i]];
      if ( pheromone[m][nn_list[m][i]] < min )
        min = pheromone[m][nn_list[m][i]];
    }
    cutoff = min + l * (max - min);

    for ( i = 0 ; i < depth ; i++ ) {
      if (pheromone[m][nn_list[m][i]] > cutoff )
        num_branches[m] += 1.0;
    }
  }
  avg = 0.0;
  for ( m = 0 ; m < problem_size ; m++ ) {
    avg += num_branches[m];
  }
  /* Norm branching factor to minimal value 1 */
  return ( avg / (double) (problem_size * 2)  );


  delete[] num_branches;
}


void check_pheromone_trail_limits( void ){
    int    i, j;

    for ( i = 0 ; i < problem_size ; i++ ) {
        for ( j = 0 ; j < i ; j++ ) {
           if ( pheromone[i][j] < trail_min ) {
               pheromone[i][j] = trail_min;
               pheromone[j][i] = trail_min;
            } else if ( pheromone[i][j] > trail_max ) {
              pheromone[i][j] = trail_max;
              pheromone[j][i] = trail_max;
         }
       }
    }
}

int find_best(void){
  int k,min,k_min;
  min = ant_population[0].tour_length;
  k_min = 0;
  for(k = 1; k < n_ants; k++){
    if(ant_population[k].tour_length < min) {
      min=ant_population[k].tour_length;
      k_min = k;
    }
  }
  return k_min; //population best ant index
}

void global_pheromone_deposit(ant *a){
  int i,j,h;
  double d_tau;
  d_tau = 1.0 / (double)a->tour_length;
  for(i = 0; i < problem_size; i++){
    j = a->tour[i];
    h = a->tour[i+1];
    pheromone[j][h]+= d_tau;
    pheromone[h][j] = pheromone[j][h];
  }
}



void evaporation(void){
 int i, j;

 for (i = 0 ; i < problem_size; i++) {
  for (j = 0 ; j <= i; j++) {
      pheromone[i][j] = (1 - rho) * pheromone[i][j];
      pheromone[j][i] = pheromone[i][j];
    }
  }
}

void mmas_pheromone_update(void){

  evaporation();
  int iteration_best;
  if (current_iteration%u_gb) {
  iteration_best = find_best();
  global_pheromone_deposit(&ant_population[iteration_best]);
  } else {
       if(u_gb == 1 && (current_iteration - restart_found_best > 50))
            global_pheromone_deposit(best_so_far_ant);
       else
            global_pheromone_deposit(restart_best_ant);

   }
   if(ls_flag == true) {
    if ( ( current_iteration - restart_iteration ) < 25 )
      u_gb = 25;
  else if ( (current_iteration - restart_iteration) < 75 )
      u_gb = 5;
  else if ( (current_iteration - restart_iteration) < 125 )
      u_gb = 3;
  else if ( (current_iteration - restart_iteration) < 250 )
      u_gb = 2;
  else
      u_gb = 1;
   } else
     u_gb = 25;

   check_pheromone_trail_limits();
}


/*P-ACO */


double distance_between(ant *a1, ant *a2){
  int i, j, h, pos, pred;
  int distance;
  int *pos2 = new int[problem_size];
  //indexes of cities of ant2
  for (int i = 0 ; i < problem_size ; i++ ) {
    pos2[a2->tour[i]] = i;
  }
  distance = 0;
  for (i = 0 ; i < problem_size ; i++ ) {
    j = a1->tour[i];
    h = a1->tour[i+1];
    pos = pos2[j];
    if (pos - 1 < 0)
      pred = problem_size - 1;
    else
      pred = pos - 1;
    if (a2->tour[pos+1] == h)
      distance++;  //common edges
    else if (a2->tour[pred] == h)
      distance++; //common edges
  }
   //free memory
  delete[] pos2;

  //     1 - (common_edges/problem size)
  return 1.0 - (distance/(double)problem_size);
}

void constant_pheromone_deposit(ant *a, double deltaT){
  int i,j,h;

  for(i = 0; i < problem_size; i++){
    j = a->tour[i];
    h = a->tour[i+1];
    pheromone[j][h]+= deltaT;
    pheromone[h][j] = pheromone[j][h];
  }
}

void constant_pheromone_removal(ant *a, double deltaT){
  int i,j,h;

  for(i = 0; i < problem_size; i++){
    j = a->tour[i];
    h = a->tour[i+1];
    pheromone[j][h]-= deltaT;
    pheromone[h][j] = pheromone[j][h];
  }
}

void paco_pheromone_update(){
    int i, iteration_best;
    ant *temp = new ant[long_memory_size];
    for(i = 0;i < long_memory_size; i++) {
      temp[i].tour = new int[problem_size+1];
      temp[i].tour_length = 0.0;
    }
    iteration_best = find_best();
    double deltaT; //amount of pheromone
    deltaT = (1.0 - trail0) / (double) long_memory_size;
    //check memory status
    //if not full
    if (current_iteration < long_memory_size){
       copy_from_to(&ant_population[iteration_best],&long_memory[long_memory_size-current_iteration-1]);
       constant_pheromone_deposit(&long_memory[long_memory_size - current_iteration-1],deltaT);
    } else {
        //revaluated/repair when change detected
        for(i = 0; i < long_memory_size; i++){
            long_memory[i].tour_length = fitness_evaluation(long_memory[i].tour);
         }
        //first in first out update policy
        for(i = 0; i < long_memory_size; i++){
          copy_from_to(&long_memory[i],&temp[i]);
        }
        //remove old ant's pheromone trails
        constant_pheromone_removal(&long_memory[long_memory_size-1], deltaT);
        for(i = 0; i < long_memory_size-1; i++){
            copy_from_to(&temp[i], &long_memory[i+1]);
        }
        //add best ant to population list
        copy_from_to(&ant_population[iteration_best],&long_memory[0]);
        //add new ants's pheromone trails
        constant_pheromone_deposit(&long_memory[0],deltaT);
    }

  //free memory
  for(i = 0; i < long_memory_size; i++)
    delete[] temp[i].tour;
   delete[] temp;
}

/*RIACO, EIACO, HIACO-I, HIACO-II, EIIACO */

int *generate_elitism_based_immigrant(){
  int *elitism_immigrant;
  int i,help,object;

  elitism_immigrant = new int[problem_size+1];
  //re-evaluate/repair the best ant from the previous environment
  //previous_best_so_far_ant->tour_length = fitness_evaluation(previous_best_so_far_ant->tour);

  //copy the previous best ant
  for(i =0; i < problem_size; i++){
    elitism_immigrant[i] = previous_best_so_far_ant->tour[i];
  }
  for(i= 0; i < problem_size; i++){
    //perform random swaps according to p_mi (small)
    if(alg_random_number(&seed) <= p_mi){
      help = 0;
      object = (int)(alg_random_number(&seed) * (double)problem_size);
      help = elitism_immigrant[i];
      elitism_immigrant[i] = elitism_immigrant[object];
      elitism_immigrant[object] = help;
    }
  }
  //close TSP tour to represent a feasible solution
  elitism_immigrant[problem_size] = elitism_immigrant[0];

  return elitism_immigrant;
}

void quick_swap(int v[], int v2[], int i, int j){
  int tmp;
  tmp = v[i];
  v[i] = v[j];
  v[j] = tmp;
  tmp = v2[i];
  v2[i] = v2[j];
  v2[j] = tmp;
}

void quick_sort(int v[], int v2[], int left, int right){
  int k,last;
  if (left >=right)
    return;
  quick_swap(v,v2,left, (left+right)/2);
  last = left;
  for(k = left+1; k <= right; k++)
    if(v[k]<v[left])
      quick_swap(v,v2,++last,k);
  quick_swap(v,v2,left,last);
  quick_sort(v,v2,left,last);
  quick_sort(v,v2,last+1,right);
}

void update_short_term_memory(){
  int i,im_size;
  int *tours = new int[n_ants];
  int *id = new int[n_ants];
  bool flag;
  //number of immigrants
  im_size = (int)ceil(short_memory_size * immigrant_rate);
  ant *immigrants = new ant[im_size];

  //add new generation of the best ants to short memory
  for(i = 0; i < n_ants; i++){
    tours[i] = ant_population[i].tour_length;
    id[i] = i;
  }
  quick_sort(tours,id,0,n_ants-1);
  for(i = 0; i < short_memory_size; i++){
    copy_from_to(&ant_population[id[i]], &short_memory[i]);
  }

  //individual information
  if(alg_mode == 3) {
    previous_best_so_far_ant->tour_length = fitness_evaluation(previous_best_so_far_ant->tour);
  }

  for(i = 0; i < im_size; i++){
    //cout << im_size <<endl;
    switch(alg_mode){
    case 2: //EIACO
      immigrants[i].tour = generate_elitism_based_immigrant();
      immigrants[i].tour_length =  fitness_evaluation(immigrants[i].tour);
      //check_tour(immigrants[i].tour);
      break;
    }

  }

  //replace immigrants with the worst ants
  for(i = short_memory_size - 1; i > short_memory_size - im_size - 1; i--){
    copy_from_to(&immigrants[short_memory_size-1-i], &short_memory[i]);
  }

  //free memory
  delete[] tours;
  delete[] id;
    for(int i =0; i < im_size; i++)
        delete[] immigrants[i].tour;
    delete[] immigrants;
}


void generate_pheromone_matrix(void){
  int i;
  double deltaT; //amount of pheromone
  deltaT = (1.0 - trail0) / (double) 2.0;
  init_pheromone_trails(pheromone,total,trail0);
  for(i = 0; i < short_memory_size; i++){
    //update pheromone using the ants stored in short memory
    constant_pheromone_deposit(&short_memory[i], deltaT);
  }
}


/*Multicolony MMAS */

void global_pheromone_deposit(ant *a, double **pheromone){
  int i,j,h;
  double d_tau;
  d_tau = 1.0 /(double)a->tour_length;

  for(i = 0; i < problem_size; i++){
    j = a->tour[i];
    h = a->tour[i+1];
    pheromone[j][h]+= d_tau;
    pheromone[h][j] = pheromone[j][h];
  }
}

int find_local_best(int id){

  int k, min, k_min;
  min = INT_MAX;
  k_min = 0;
  for (k = 0; k < n_ants; k++){
    if(ant_population[k].id == id){
       if(ant_population[k].tour_length < min) {
          min = ant_population[k].tour_length;
          k_min = k;
       }
    }
  }

return k_min;
}

void update_local_best(int id, double trail_min, double trail_max, ant *best){
  int iteration_best = find_local_best(id);
  double p_x;
  if(id == ant_population[iteration_best].id){
  if(ant_population[iteration_best].tour_length < best->tour_length) {
    copy_from_to(&ant_population[iteration_best],best);
//cout << best->tour_length << endl;
   // copy_from_to(&ant_population[iteration_best],restart_best_ant_1);
    new_best_found = true;
    found_best = current_iteration;
    if(id == 1) restart_found_best_1 = current_iteration;
    if(id == 2) restart_found_best_2 = current_iteration;
    //found_branching = node_branching(lambda,pheromone1);
    //branching_factor = found_branching;
    if(ls_flag == true){
      p_x = exp(log(0.05)/problem_size);
      trail_min = 1.0 * (1.0 - p_x) / (p_x * (double)((depth + 1) / 2.0));
      trail_max = 1.0 / ( (rho) * best->tour_length );
      //trail0 = trail_max_1;
      trail_min = trail_max * trail_min;
    } else {
      trail_max = 1. / ( (rho) * best->tour_length );
      trail_min = trail_max / ( 2. * problem_size );
      //trail0 = trail_max_1;
    }
  }
  }
  if(ant_population[iteration_best].id == 1){
    if(ant_population[iteration_best].tour_length < restart_best_ant_1->tour_length) {
     copy_from_to(&ant_population[iteration_best], restart_best_ant_1);
     restart_found_best_1 = current_iteration;
      cout << "restart best 1: " << restart_best_ant_1->tour_length << " restart_found_best 1: " << restart_found_best_1 << endl;
    }
  }
  if(ant_population[iteration_best].id == 2){
    if(ant_population[iteration_best].tour_length < restart_best_ant_2->tour_length) {
     copy_from_to(&ant_population[iteration_best], restart_best_ant_2);
     restart_found_best_2 = current_iteration;
     cout << "restart best 2: " << restart_best_ant_2->tour_length << " restart_found_best 2: " << restart_found_best_2 << endl;
    }
  }
}

void evaporation(double **pheromone, double rho){
 int i, j;

 for (i = 0 ; i < problem_size; i++) {
  for (j = 0 ; j <= i; j++) {
      pheromone[i][j] = (1.0 - rho) * pheromone[i][j];
      pheromone[j][i] = pheromone[i][j];
  }
    }
}

void mmas_pheromone_update(int id){

  int iteration_best;
  if (current_iteration%u_gb) {
    iteration_best = find_local_best(id);
    if(id==1)global_pheromone_deposit(&ant_population[iteration_best],pheromone1);
    if(id==2)global_pheromone_deposit(&ant_population[iteration_best],pheromone2);
  } else {
        if(id==1) {
           if(u_gb == 1 && (current_iteration - restart_found_best_1 > 50))
            global_pheromone_deposit(best_so_far_ant_1,pheromone1);
           else
            global_pheromone_deposit(restart_best_ant_1,pheromone1);
        }
        if(id==2) {
           if(u_gb == 1 && (current_iteration - restart_found_best_2 > 50))
            global_pheromone_deposit(best_so_far_ant_2,pheromone2);
           else
            global_pheromone_deposit(restart_best_ant_2,pheromone2);
        }

   }
   if(ls_flag == true) {
     if(id==1){
      if ( ( current_iteration - restart_iteration_1 ) < 25 )
      u_gb = 25;
  else if ( (current_iteration - restart_iteration_1) < 75 )
      u_gb = 5;
  else if ( (current_iteration - restart_iteration_1) < 125 )
      u_gb = 3;
  else if ( (current_iteration - restart_iteration_1) < 250 )
      u_gb = 2;
  else
      u_gb = 1;
     }
     if(id==2){
      if ( ( current_iteration - restart_iteration_2 ) < 25 )
      u_gb = 25;
  else if ( (current_iteration - restart_iteration_2) < 75 )
      u_gb = 5;
  else if ( (current_iteration - restart_iteration_2) < 125 )
      u_gb = 3;
  else if ( (current_iteration - restart_iteration_2) < 250 )
      u_gb = 2;
  else
      u_gb = 1;
     }
    } else
     u_gb = 25;


}

void check_pheromone_trail_limits(double **pheromone, double trail_min, double trail_max){
    int    i, j;

    for ( i = 0 ; i < problem_size ; i++ ) {
  for ( j = 0 ; j < i ; j++ ) {
      if ( pheromone[i][j] < trail_min ) {
    pheromone[i][j] = trail_min;
    pheromone[j][i] = trail_min;

      } else if ( pheromone[i][j] > trail_max ) {
    pheromone[i][j] = trail_max;
    pheromone[j][i] = trail_max;

      }
  }
    }
}

double local_node_branching(double l, double** phe) {
  int  i, m;
  double min, max, cutoff;
  double avg;
  double *num_branches = new double[problem_size];
 /* for (i = 0; i < problem_size; i++){
    num_branches[i] = 0.0;
  }*/
  for ( m = 0 ; m < problem_size ; m++ ) {
    /* determine max, min to calculate the cutoff value */
    min = phe[m][nn_list[m][1]];
    max = phe[m][nn_list[m][1]];
    for ( i = 1 ; i < depth ; i++ ) {
      if ( phe[m][nn_list[m][i]] > max )
  max = phe[m][nn_list[m][i]];
      if ( phe[m][nn_list[m][i]] < min )
  min = phe[m][nn_list[m][i]];
    }
    cutoff = min + l * (max - min);

    for ( i = 0 ; i < depth ; i++ ) {
      if (phe[m][nn_list[m][i]] > cutoff )
  num_branches[m] += 1.0;
    }
  }
  avg = 0.0;
  for ( m = 0 ; m < problem_size ; m++ ) {
    avg += num_branches[m];
  }

  /* Norm branching factor to minimal value 1 */
  return ( avg / (double) (problem_size * 2)  );


  delete[] num_branches;
}

void repair_action(void){
     //Only when the location of the dynamic changes is available

     if(alg_mode == 2 ){
        double deltaT; //amount of pheromone
        deltaT = (1.0 - trail0) / (double) long_memory_size;
        for(int i = 0; i < long_memory_size; i++){
            //repair solution in population and update pheromone trails accordingly
            constant_pheromone_removal(&long_memory[i],deltaT);
            repair_solution_heuristically(long_memory[i].tour);
            constant_pheromone_deposit(&long_memory[i],deltaT);
        }
        compute_total_info(total,pheromone);
     }

    if(alg_mode == 3 ){
       repair_solution_heuristically(previous_best_so_far_ant->tour);
        double deltaT; //amount of pheromone
        deltaT = (1.0 - trail0) / (double) 2.0;
        for(int i = 0; i < short_memory_size; i++){
            //repair solution in population and update pheromone trails accordingly
            constant_pheromone_removal(&short_memory[i],deltaT);
            repair_solution_heuristically(short_memory[i].tour);
            constant_pheromone_deposit(&short_memory[i],deltaT);
        }
        compute_total_info(total,pheromone);
    }
    if(alg_mode == 1 || alg_mode == 4) { 
      repair_solution_heuristically(best_so_far_ant->tour);
      best_so_far_ant->tour_length = fitness_evaluation(best_so_far_ant->tour);
      if(alg_mode == 4) {
        repair_solution_heuristically(best_so_far_ant_1->tour);
        repair_solution_heuristically(best_so_far_ant_2->tour);  
        best_so_far_ant_1->tour_length = fitness_evaluation(best_so_far_ant_1->tour);
        best_so_far_ant_2->tour_length = fitness_evaluation(best_so_far_ant_2->tour);
      }
    }
}

void action_when_change_detected(void){
  int i, j;
  if(detect_change_single() == true) {
     //apply changes to ACO algorithms
     //for offline performance measure
     //best_so_far_ant->tour_length = INFTY;
     /*enable elitism strategy*/
     best_so_far_ant->tour_length = fitness_evaluation(best_so_far_ant->tour);
     /*-------------------*/
     compute_nn_lists();
     init_heuristic_info();
     if(alg_mode != 4 ){
        compute_total_info(total,pheromone); //heuristic info + pheromone trails
     } else {
        compute_total_info(total1,pheromone1);
        compute_total_info(total2,pheromone2);
     }
     /*repair_action();*/
  }
}


/*Main methods */

void construct_solutions(void){
  int k,step;
  //keep structes uptodate and perform action when a change occurs for some algrorithms
  action_when_change_detected();
  //clear memory of ants
  for(k =0; k < n_ants; k++){
    ant_empty_memory(&ant_population[k]);
  }
  step = 0;
  //place ants on a random object
  for(k =0; k < n_ants; k++){
    place_ant(&ant_population[k],step);
  }
  //select object until all objects are visited
  while(step < problem_size-1){
    step++;
    for(k =0; k < n_ants; k++){
      if(alg_mode == 4) {
        if(ant_population[k].id == 1) neighbour_choose_and_move_to_next(&ant_population[k],step,total1);
        if(ant_population[k].id == 2) neighbour_choose_and_move_to_next(&ant_population[k],step,total2);
      } else {
         neighbour_choose_and_move_to_next(&ant_population[k],step, total);
      }
    }
  }
  step = problem_size;

  for(k = 0; k < n_ants; k++){
    //close TSP tour, i.e., the first object needs to be identical with the last one.
    ant_population[k].tour[problem_size] = ant_population[k].tour[0];
    if(ls_flag == true) two_opt_first(ant_population[k].tour);
    ant_population[k].tour_length = fitness_evaluation(ant_population[k].tour);//evalute
  }
}

void update_best(void){
  double p_x;
  int i;
  int iteration_best = find_best();
  if(ant_population[iteration_best].tour_length < best_so_far_ant->tour_length) {
    copy_from_to(&ant_population[iteration_best],best_so_far_ant);
    if(alg_mode == 1) {
       copy_from_to(&ant_population[iteration_best],restart_best_ant);
       found_best = current_iteration;
       restart_found_best = current_iteration;
       if(ls_flag == false){
                p_x = exp(log(0.05)/problem_size);
                trail_min = 1.0 * (1.0 - p_x) / (p_x * (double)((depth + 1) / 2.0));
                trail_max = 1.0 / ( (rho) * best_so_far_ant->tour_length );
                trail0 = trail_max;
                trail_min = trail_max * trail_min;
            } else {
                 trail_max = 1. / ( (rho) * best_so_far_ant->tour_length );
                 trail_min = trail_max / ( 2. * problem_size );
                 trail0 = trail_max;
       }
    }
  }
 if(alg_mode == 1 ) {
   if(ant_population[iteration_best].tour_length < restart_best_ant->tour_length) {
       copy_from_to(&ant_population[iteration_best], restart_best_ant);
       restart_found_best = current_iteration;
       cout << "restart best: " << restart_best_ant->tour_length << " restart_found_best: " << restart_found_best << endl;
    }
  }
}


void pheromone_update(){
  if(alg_mode == 3){
    update_short_term_memory();
    generate_pheromone_matrix();
  }

  if(alg_mode == 1 ) {
     mmas_pheromone_update();
  }

  if(alg_mode == 2) {
    paco_pheromone_update();
  }
  if(alg_mode == 4){
     //update best
     evaporation(pheromone1, rho);
     evaporation(pheromone2, rho);
     update_local_best(1,trail_min_1, trail_max_1, best_so_far_ant_1);
     update_local_best(2,trail_min_2, trail_max_2, best_so_far_ant_2);

     mmas_pheromone_update(1);
     mmas_pheromone_update(2);

     //migrate
     global_pheromone_deposit(best_so_far_ant,pheromone1);
     global_pheromone_deposit(best_so_far_ant,pheromone2);

     check_pheromone_trail_limits(pheromone1,trail_min_1,trail_max_1);
     check_pheromone_trail_limits(pheromone2,trail_min_2,trail_max_2);
  }
  if(alg_mode != 4 ){
        compute_total_info(total,pheromone); //heuristic info + pheromone trails
     } else {
        //for multicolony MMAS
        compute_total_info(total1,pheromone1);
        compute_total_info(total2,pheromone2);
     }

}


void statistics_and_output(){
 // current_iteration++; //algorithmic iteration
  //cout<<"iteration: " << get_evals() <<  " best_so_far " << get_current_best() <<  " " << get_current_error() << endl;
  /*if(alg_mode == 1){
    if (!(current_iteration%1)) {
  branching_factor = node_branching(lambda);
  if ((branching_factor < branch_fac) && (current_iteration - restart_found_best > 250) ) {
      cout << "INIT TRAILS!!!" << endl;
      restart_best_ant->tour_length = INFTY;
      init_pheromone_trails(pheromone,total,trail_max);
      compute_total_info(total,pheromone);
     restart_iteration = current_iteration;
  }
  //cout << branching_factor << endl;
    }
   } else if (alg_mode == 4) {
      if(!(current_iteration%1)) {
  branching_factor = local_node_branching(lambda,pheromone1);
  if ((branching_factor < branch_fac) && (current_iteration - restart_found_best_1 > 250) ) {

      cout << "INIT TRAILS!!!" << endl;
      restart_best_ant_1->tour_length = INFTY;
      init_pheromone_trails(pheromone1,total1,trail_max_1);
      compute_total_info(total1,pheromone1);
      restart_iteration_1 = current_iteration;
  }
  branching_factor = local_node_branching(lambda,pheromone2);
  if ((branching_factor < branch_fac) && (current_iteration - restart_found_best_2 > 250) ) {

      cout << "INIT TRAILS!!!" << endl;
      restart_best_ant_2->tour_length = INFTY;
      init_pheromone_trails(pheromone2,total2,trail_max_2);
      compute_total_info(total2,pheromone2);
      restart_iteration_2 = current_iteration;
  }
      }

   } */
   //keep track of previous best_so_far
   copy_from_to(best_so_far_ant, previous_best_so_far_ant);

   current_iteration++;
}

int *generate_random_immigrant(){
  int *random_immigrant;
  int i,help, object, tot_assigned =0;
  int *r;

  random_immigrant = new int[problem_size+1];
  r = new int[problem_size];
  //set indexes of objects
  for(i = 0; i < problem_size; i++){
    r[i]=i;
  }
  //randomly change indexes of objects
  for(i = 0; i < problem_size; i++){
    object = (int) (alg_random_number(&seed) * (double)(problem_size-tot_assigned));
    help = r[i];
    r[i]=r[i+object];
    r[i+object]=help;
    tot_assigned++;
  }
  //generate random immigrant
  for(int i = 0; i < problem_size; i++){
    random_immigrant[i]=r[i];
  }
  //close TSP tour to represent a feasible solution
  random_immigrant[problem_size] = random_immigrant[0];

  //free memory
  delete[] r;

  return random_immigrant;
}



void initialize_ACO(int r){
  int i;
  seed = r; // change the seed for another run
  current_iteration = 0;
  best_so_far_ant->tour_length = INT_MAX; //reset best solution found
  previous_best_so_far_ant->tour_length = INT_MAX;
  compute_nn_lists();             //reset nearest neighbour objects
  init_heuristic_info();          //initialize heuristic info
  nn_tour();                      //to initialize previous_best_so_far

  //initialize pheromone trails
  if( alg_mode == 3 || alg_mode == 2) {
      trail0 = 1.0 / (double)(problem_size - 1);
  } else if ( alg_mode == 1 ){
      //reset rate for algorithms that adapt it
      restart_iteration = 1;
      found_best = 0;
      trail_max = 1.0 / ( (rho) * nn_tour() );
      trail_min = trail_max / ( 2.0 * problem_size );
      trail0 = trail_max;

  } else if (alg_mode == 4){
     restart_iteration = 1;
     found_best = 0;
     best_so_far_ant_1->tour_length = INT_MAX;
     best_so_far_ant_2->tour_length = INT_MAX;
     trail_max_1 = 1.0 / ( (rho) * nn_tour() );
     trail_min_1 = trail_max_1 / ( 2.0 * problem_size );
     trail_max_2 = 1.0 / ( (rho) * nn_tour() );
     trail_min_2 = trail_max_2 / ( 2.0 * problem_size );
     init_pheromone_trails(pheromone1,total1,trail_max_1);
     init_pheromone_trails(pheromone2,total2,trail_max_2);
     compute_total_info(total1,pheromone1);
     compute_total_info(total2,pheromone2);
     restart_iteration_1 = 1;
     restart_iteration_2 = 1;
     new_best_found = false;
  } 

  init_pheromone_trails(pheromone,total,trail0); //initialize pheromone trails
  compute_total_info(total,pheromone);           //combine heuristic+pheromone

  detector->tour = generate_random_immigrant();
  detector->tour_length = fitness_evaluation(detector->tour);

}

void ACO(void){

      construct_solutions();

      update_best();

      pheromone_update();

      statistics_and_output();

}


void free_ACO_memory(){
   //free memory from the ACO implementation
   delete[] detector->tour;
   delete[] detector->visited;
   delete[] restart_best_ant->tour;
   delete[] restart_best_ant->visited;

  if(alg_mode == 2){
    for(int i = 0; i < long_memory_size; i++)
      delete[] long_memory[i].tour;
   delete[] long_memory;
  }
  delete[] best_so_far_ant->tour;
  delete[] best_so_far_ant->visited;
  for(int i = 0; i < n_ants; i++){
    delete[] ant_population[i].tour;
    delete[] ant_population[i].visited;
  }
  delete[] ant_population;

  delete[] previous_best_so_far_ant->tour;
  delete[] previous_best_so_far_ant->visited;

  for(int i =0; i <problem_size; i++){
    delete[] pheromone[i];
    delete[] heuristic[i];
    delete[] total[i];
    delete[] nn_list[i];
  }
  delete[] pheromone;
  delete[] heuristic;
  delete[] total;
  delete[] nn_list;
  delete[] prob_of_selection;
  if(alg_mode == 4){
    for(int i =0; i< problem_size; i++){
        delete[] pheromone1[i];
        delete[] pheromone2[i];
        delete[] total1[i];
        delete[] total2[i];
    }
    delete[] pheromone1;
    delete[] pheromone2;
    delete[] total1;
    delete[] total2;
    delete[] best_so_far_ant_1->tour;
    delete[] best_so_far_ant_1->visited;
    delete[] best_so_far_ant_2->tour;
    delete[] best_so_far_ant_2->visited;
    delete[] restart_best_ant_1->tour;
    delete[] restart_best_ant_1->visited;
    delete[] restart_best_ant_2->tour;
    delete[] restart_best_ant_2->visited;
  }

  if(alg_mode == 3){
     for(int i =0; i < short_memory_size; i++){
        delete[] short_memory[i].tour;
     }
     delete[] short_memory;
  }


}

//end ACO
