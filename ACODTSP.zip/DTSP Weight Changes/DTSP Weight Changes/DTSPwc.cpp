/****************************************************************************/
/*                                                                          */
/*        This is an implementation of the DTSP with weight changes         */
/*                                                                          */
/*                                                                          */
/****************************************************************************/


#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<string>
#include<cstring>
#include<math.h>
#include<fstream>
#include<time.h>
#include<limits.h>

#include "DTSPwc.hpp"
#include "stats.hpp"

using namespace std;

struct object *init_objects;     /*actual objects of the instance*/
double **modify_factors;         /*modified factors matrix*/

int **distances;                 /*distance matrix*/
char* problem_instance;          /*name of the instance*/
int problem_size;                /*number of cities*/

double change_degree;            /*ratio of swapped objects*/
int change_speed;                /*period of changes in algorithmic iterations*/
int total_changes; 		         /*how many environmental changes*/

/*this parameters can be modified to increase or decrease the amount of change*/
double mu = 0.0;
double sigma;

double offline_performance;
double before_change;
double pop_diversity;
double tot_robustness;

double current_best;


/****************************************************************/
/*Random number generator where the seed is the same in all runs*/
/****************************************************************/
double env_random_number(double low, double high) {
  return ((double)(rand()%10000)/10000.0)*(high - low) + low;
}

/****************************************************************/
/*Random seed used from the env_random_number() method          */
/****************************************************************/
void reset_random_seed(){
 /*sreset seed to get the same consecutive dynamic changes for each run*/
 srand(1);
}

/****************************************************************/
/*Normally distributed number used to increase or decrease      */
/*the weights                                                   */
/****************************************************************/
double normal(double mu, double sigma, double lower, double higher){
  double p, p1, p2, v;
  do{
    p1 = env_random_number(-1.0,1.0);
    p2 = env_random_number(-1.0,1.0);

    p = (p1 * p1) + (p2 * p2);
  } while (p >= 1.0);
   // if (p == 0 || p > 1) return rand_num(-1.0,1.0);
    v = mu + (sigma * p1 * sqrt(-2.0 * (log(p)/p)));
    return v;
}

/****************************************************************/
/*           Initialize all modify factors equally             */
/****************************************************************/
void initialize_modify_factors(){
  int i,j;
  for(i = 0; i < problem_size; i++){
   for(j = 0; j <= i; j++) {
     modify_factors[i][j] = 0.0;
     modify_factors[j][i] = modify_factors[i][j];
   }
  }
}

/****************************************************************/
/*Compute and return the euclidean distance of two objects      */
/****************************************************************/
int euclidean_distance(int i, int j) {
  double xd,yd;
  int r = 0;
  xd = init_objects[i].x - init_objects[j].x;
  yd = init_objects[i].y - init_objects[j].y;
  r  = sqrt(xd*xd + yd*yd) + 0.5;
  return r;
}

/****************************************************************/
/*Compute the distance matrix of the problem instance           */
/****************************************************************/
void compute_distances(void) {
int i, j;
int e2d;
  for(i = 0; i < problem_size; i++){
    for(j = 0; j < problem_size; j++){
      e2d = euclidean_distance(i,j);
      distances[i][j] = e2d + modify_factors[i][j];
      
      //in case a negative distance occurs
      if(distances[i][j] <= 0 && i!=j) distances[i][j] = e2d + abs(modify_factors[i][j]);	
     // cout << "from node " << i << " to node " << j << " : " <<  distances[i][j] << " value : "  << modify_factors[i][j] << endl;
    }
  }
}


/****************************************************************/
/*          Modify the arc from one node to another node        */
/****************************************************************/
void modify_weight(int from, int to){
    double value;
    //cout << value << endl;
    sigma = 0.2 * euclidean_distance(from,to);
    value = normal(mu,sigma,-10,10);
    modify_factors[from][to] = value;
    modify_factors[to][from] = modify_factors[from][to];

}


/****************************************************************/
/* Perform random changes to a predefined arcs according to the */
/* magnitude of change                                          */
/*                                                              */
/****************************************************************/
void add_random_change(void){
  int i,j,k;
  //calculate total number of arcs for symmetric cases
  int num_arcs = (problem_size * (problem_size - 1))/2.0;
  //int k = (problem_size * (problem_size - 1)); for asymmetric
  int changes = (int)abs(change_degree * num_arcs);
  int** changed = generate_2D_matrix_int(problem_size,problem_size);

  /*Implementing the clustered method in DTSP with node changes it is also 
  possible to restrict the selection of the arcs from a set of clustered 
  cities. In this implementation the selected arcs are NOT restricted*/

  //vary the weights of the arcs
  k = 0;
  for(i = 0; i < problem_size; i++){
    for(j = 0; j < i; j++){
      if(env_random_number(0.0,1.0) <= change_degree){
        if(k>=changes) break;
        modify_weight(i,j);
        changed[i][j] = 1;
        changed[j][i] = 1;
        k++;
      }
    }
  }

  //vary the weights of more arcs in case the total changes number does not match k
  int h1, h2;
  while(k < changes){
    h1 = env_random_number(0,problem_size);
    h2 = env_random_number(0,problem_size);
    if(changed[h1][h2] == 0){
        modify_weight(h1,h2);
	changed[h1][h2] = 1;
	changed[h2][h1] = 1;
        k++;
    }
  }

  //cout << "total arcs" << k << " " << changes <<  endl;

  //free changed memory
  for(int i =0; i < problem_size; i++) {
    delete[] changed[i];
  }
  delete[] changed;
}

/****************************************************************/
/*Generate and return a two-dimension array of type int         */
/****************************************************************/
int ** generate_2D_matrix_int(int n, int m){
  int **matrix;
  matrix = new int*[n];
  for ( int i = 0 ; i < n ; i++ ) {
    matrix[i] = new int[m];
  }
  /*initialize the 2-d array*/
  for(int i = 0; i < n; i++){
    for(int j = 0; j < m; j++) {
      matrix[i][j] = 0;
    }
  }
  return matrix;
}

/****************************************************************/
/*Generate and return a two-dimension array of type double      */
/****************************************************************/
double ** generate_2D_matrix_double(int n, int m){
  double **matrix;

  matrix = new double*[n];
  for ( int i = 0 ; i < n ; i++ ) {
    matrix[i] = new double[m];
  }
  /*initialize the 2-d array*/
  for(int i = 0; i < n; i++){
    for(int j = 0; j < m; j++) {
      matrix[i][j] = 0.0;
    }
  }
  return matrix;
}

/****************************************************************/
/* Validate the values input by the user                        */
/****************************************************************/
void check_input_parameters() {

 if(problem_size == 0) {
   cout << "wrong problem instance file" << endl;
   exit(1);
 }
 if(change_degree > 1.0 || change_degree <= 0.0) {
   cout << "select a valid change degree (between 0..1)" << endl;
   exit(2);
 }
 if(change_speed <= 0) {
   cout << "select a valid change speed (int)" << endl;
   exit(1);
 }
 if(total_changes <= 0) {
    cout << "select total changes" << endl;
 }
}

/****************************************************************/
/* Read the problem instance and generate the initial object    */
/* vector.                                                      */
/****************************************************************/
void read_problem(char* filename){
  char line[CHAR_LEN];
  char * keywords;
  char Delimiters[] = " :=\n\t\r\f\v";
  ifstream fin(filename);
  while((fin.getline(line, CHAR_LEN-1))){
    if(!(keywords = strtok(line, Delimiters)))
      continue;
    if(!strcmp(keywords, "DIMENSION")){
      if(!sscanf(strtok(NULL, Delimiters), "%d", &problem_size)){
	cout<<"DIMENSION error"<<endl;
	exit(0);
      }
    }
    else if(!strcmp(keywords, "EDGE_WEIGHT_TYPE")){
      char * tempChar;
      if(!(tempChar=strtok(NULL, Delimiters))){
	cout<<"EDGE_WEIGHT_TYPE error"<<endl;
	exit(0);
      }
      if(strcmp(tempChar, "EUC_2D")){
	cout<<"not EUC_2D"<<endl;
	exit(0);
      }
    }
    else if(!strcmp(keywords, "NODE_COORD_SECTION")){
      if(problem_size!=0){
      init_objects = new object[problem_size];
      int i;

      for(i=0; i < problem_size; i++){
	   /*store objects*/
        fin>>init_objects[i].id;
	    fin>>init_objects[i].x>>init_objects[i].y;
        init_objects[i].id -=1;
      }
      /*compute the distances using initial objects and initial weights*/
       distances = generate_2D_matrix_int(problem_size, problem_size);
       modify_factors = generate_2D_matrix_double(problem_size,problem_size);
       initialize_modify_factors();
       compute_distances();

     }
    }
  }
  fin.close();
  check_input_parameters();   /*validate the parameters*/
}

/****************************************************************/
/* Initialize the environment to                                */
/* perform the same dynamic changes                             */
/****************************************************************/
void initialize_environment(){
  //Set the random seed
  reset_random_seed();
  //reset the metrics
  offline_performance = 0.0;
  before_change = 0.0;
  pop_diversity = 0.0;
  tot_robustness = 0.0;

  initialize_modify_factors();

  add_random_change();
  compute_distances();
  current_best = INFTY;
}

/****************************************************************/
/* Perform the dynamic change every "period" iteration          */
/*                                                              */
/****************************************************************/
void change_environment(){

    add_random_change();
    compute_distances();  /*update weight matrix*/
    current_best = INFTY; /*reset current best*/

}


/****************************************************************/
/* Evaluate a TSP tour and return the length. This method can   */
/* be used in the algorithm. The TSP tour                       */
/* to input is an array of integers, where each integer         */
/* corresponds to an object                                     */
/****************************************************************/
double fitness_evaluation(int *t) {
  int i;
  double tour_length = 0.0;

  /*hamiltonian path - last city is connected with the first one*/
  for (i = 0 ; i < problem_size; i++ ) {
    tour_length += distances[t[i]][t[(i+1)%problem_size]];
  }
  /*keep track of the best so far after a change*/
  if(tour_length < current_best){
    current_best = tour_length;
  }

  return tour_length;
}


/*return performance and behaviour measurements */
double get_offline_performance(){
    return offline_performance/(double)TERMINATION;
}

double get_before_change(){
    return before_change/(double)total_changes;
}

double get_pop_diversity(){
    return pop_diversity/(double)TERMINATION;
}

double get_robustness(){
    return tot_robustness/((double)total_changes-1);
}

int get_current_best(){
    return current_best;
}

int get_problem_size(){
    return problem_size;
}


void free_DTSP_memory(){
  delete[] init_objects;
  for(int i =0; i < problem_size; i++) {
    delete[] distances[i];
    delete[] modify_factors[i];
  }
  delete[] distances;
  delete[] modify_factors;

}
