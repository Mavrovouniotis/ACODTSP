#define INFTY    INT_MAX
#define CHAR_LEN 100
#define TERMINATION	(total_changes*change_speed)

struct object {
  int id;
  double x;
  double y;
};

/*user input parameters*/
extern char* problem_instance;          /*name of the instance*/
extern double change_degree;            /*ratio of swapped objects*/
extern int change_speed;                /*peiord of changes in algorithmic iterations*/
extern int total_changes; 		        /*number of environmental changes*/
extern int type_of_change;				/*nodes or weight changes*/

/*these parameter are used in the stat class*/
extern double offline_performance;
extern double before_change;
extern double pop_diversity;
extern double tot_robustness;

/*methods and parameters that can be used in the optimizer implementation*/
extern int **distances;                 /*distance matrix*/
extern int problem_size;                /*size of the instance*/
extern object *current_pool;

/*this methods and information are optional because they use change-related information
and they can be used only with Node Changes*/
void repair_solution_heuristically(int *t);
bool check_offended_city(int i);
extern int **complete_distances;
extern int *offended_nodes;
extern int *affected;

/*use it to evaluate the fitness of the algorithm*/
double fitness_evaluation(int *t);

/*use them to generate DTSP. An example is given in main.cpp*/
void read_problem(char* filename);
void initialize_environment();
void change_environment();

/*use them to output offline performance, diversity and best before a change*/
int get_current_best();
double get_offline_performance();
double get_pop_diversity();
double get_before_change();
double get_robustness();

int** generate_2D_matrix_int(int n, int m);
double ** generate_2D_matrix_double(int n, int m);
void free_DTSP_memory();




